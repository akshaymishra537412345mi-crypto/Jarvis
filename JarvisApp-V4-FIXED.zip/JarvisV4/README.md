# J.A.R.V.I.S. — Android AI Assistant
### Just A Rather Very Intelligent System

A real background voice assistant for Android, powered by Claude AI.  
Say "Hey Jarvis" and speak — in English or Hindi — from anywhere on your phone.

---

## ✅ FEATURES

- 🎙️ **Wake word detection** — "Hey Jarvis", "Jarvis", "OK Jarvis" / "जार्विस", "हे जार्विस"
- 🌐 **English + Hindi** voice recognition
- 🤖 **Claude AI** (Anthropic) responses — witty, in-character Jarvis personality
- 🗣️ **Text-to-Speech** voice replies
- 📱 **Overlay popup** appears over any app you're using
- 🔁 **Background service** — runs silently 24/7
- 🔌 **Auto-starts on boot** (enable in settings)
- ⚡ **Auto-dismisses** popup after Jarvis finishes speaking

---

## 🛠️ HOW TO BUILD & INSTALL

### Requirements
- **Android Studio** (Hedgehog 2023.1.1 or newer) — download from developer.android.com
- **Android phone** running Android 8.0 (API 26) or newer
- **Anthropic API key** — get one free at console.anthropic.com

### Steps

1. **Open in Android Studio**
   - Open Android Studio → "Open an Existing Project"
   - Select the `JarvisApp` folder
   - Wait for Gradle sync to finish (~2 minutes)

2. **Connect your Android phone**
   - Enable Developer Options: Settings → About Phone → tap "Build Number" 7 times
   - Enable USB Debugging: Settings → Developer Options → USB Debugging
   - Connect phone via USB cable
   - Accept the "Allow USB Debugging" prompt on your phone

3. **Build & Install**
   - In Android Studio: Run → Run 'app'  (or press Shift+F10)
   - Select your device and click OK
   - The app installs automatically

4. **First-time setup on phone**
   - Open **J.A.R.V.I.S.** app
   - Tap **"Grant Overlay Permission"** → enable it in settings → go back
   - Enter your **Anthropic API key** (starts with `sk-ant-...`)
   - Tap **"ACTIVATE JARVIS"**
   - Grant **Microphone permission** when prompted

5. **You're done!**  
   Say *"Hey Jarvis"* from anywhere. Even with your screen on another app.

---

## 🎤 WAKE WORDS

| Language | Say |
|----------|-----|
| English  | "Hey Jarvis" / "Jarvis" / "OK Jarvis" / "Hello Jarvis" |
| Hindi    | "जार्विस" / "हे जार्विस" / "ओके जार्विस" |

---

## 💬 EXAMPLE COMMANDS

| English | Hindi |
|---------|-------|
| "What's the weather today?" | "आज मौसम कैसा है?" |
| "What time is it?" | "अभी क्या समय है?" |
| "Tell me a joke" | "कोई मज़ेदार बात बताओ" |
| "What is 25 times 48?" | "25 गुना 48 क्या होता है?" |
| "Write a haiku about Mumbai" | "मुझे एक कविता सुनाओ" |

---

## ⚙️ TROUBLESHOOTING

**"It's not hearing me"**
- Make sure microphone permission is granted (Settings → Apps → Jarvis → Permissions)
- Speak clearly; say "Hey Jarvis" first, then pause 1 second, then your command

**"Overlay not showing"**
- Settings → Apps → Special App Access → Display over other apps → J.A.R.V.I.S. → Allow

**"API error"**
- Check your Anthropic API key is correct
- Make sure you have internet connection
- Check you have API credits at console.anthropic.com

**"Stops working after a while"**
- Some phones (Xiaomi, Samsung, Huawei) aggressively kill background apps
- Go to Settings → Battery → App launch / Background apps → set Jarvis to "Manage manually" → enable all 3 options

---

## 📁 PROJECT STRUCTURE

```
JarvisApp/
├── app/src/main/
│   ├── java/com/jarvis/ai/
│   │   ├── MainActivity.kt      ← Setup screen
│   │   ├── JarvisService.kt     ← Core background service
│   │   └── BootReceiver.kt      ← Auto-start on boot
│   ├── res/
│   │   ├── layout/
│   │   │   ├── activity_main.xml   ← Setup UI
│   │   │   └── overlay_popup.xml   ← HUD popup
│   │   └── ...
│   └── AndroidManifest.xml
└── app/build.gradle
```

---

## 🔐 PRIVACY

- Your API key is stored only on your device (SharedPreferences)
- Voice is processed by Google's on-device speech recognizer
- Commands are sent to Anthropic's API over HTTPS
- No data is stored or logged by this app

---

*Built with ❤️ using Claude AI*
