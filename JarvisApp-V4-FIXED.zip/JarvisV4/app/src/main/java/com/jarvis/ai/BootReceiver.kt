package com.jarvis.ai

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED ||
            intent.action == "android.intent.action.QUICKBOOT_POWERON") {

            val prefs  = context.getSharedPreferences("jarvis_prefs", Context.MODE_PRIVATE)
            val apiKey = prefs.getString("api_key", "") ?: ""
            val autoStart = prefs.getBoolean("auto_start", false)

            if (apiKey.isNotEmpty() && autoStart) {
                val serviceIntent = Intent(context, JarvisService::class.java)
                serviceIntent.putExtra("api_key", apiKey)
                context.startForegroundService(serviceIntent)
            }
        }
    }
}
