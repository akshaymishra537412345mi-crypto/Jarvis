package com.jarvis.ai

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.telecom.TelecomManager
import android.telephony.TelephonyManager

class CallReceiver : BroadcastReceiver() {

    companion object {
        var lastState = TelephonyManager.CALL_STATE_IDLE
    }

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != TelephonyManager.ACTION_PHONE_STATE_CHANGED) return

        val state  = intent.getStringExtra(TelephonyManager.EXTRA_STATE) ?: return
        val number = intent.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER) ?: ""

        when (state) {
            TelephonyManager.EXTRA_STATE_RINGING -> {
                // Incoming call — get contact name
                val name = getContactName(context, number) ?: number.ifEmpty { "Unknown number" }

                // Notify Jarvis service to announce the call
                val serviceIntent = Intent(context, JarvisService::class.java).apply {
                    action = JarvisService.ACTION_INCOMING_CALL
                    putExtra("caller_name",   name)
                    putExtra("caller_number", number)
                }
                context.startForegroundService(serviceIntent)
            }

            TelephonyManager.EXTRA_STATE_OFFHOOK -> {
                // Call was answered
                if (lastState == TelephonyManager.CALL_STATE_RINGING) {
                    // Put on speakerphone automatically
                    Handler(Looper.getMainLooper()).postDelayed({
                        try {
                            val audio = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
                            audio.isSpeakerphoneOn = true
                            audio.mode = AudioManager.MODE_IN_CALL
                        } catch (e: Exception) { e.printStackTrace() }
                    }, 1500)
                }
            }

            TelephonyManager.EXTRA_STATE_IDLE -> {
                if (lastState != TelephonyManager.CALL_STATE_IDLE) {
                    // Call ended
                    val endIntent = Intent(context, JarvisService::class.java).apply {
                        action = JarvisService.ACTION_CALL_ENDED
                    }
                    context.startForegroundService(endIntent)
                }
            }
        }

        lastState = when (state) {
            TelephonyManager.EXTRA_STATE_IDLE     -> TelephonyManager.CALL_STATE_IDLE
            TelephonyManager.EXTRA_STATE_RINGING  -> TelephonyManager.CALL_STATE_RINGING
            TelephonyManager.EXTRA_STATE_OFFHOOK  -> TelephonyManager.CALL_STATE_OFFHOOK
            else -> lastState
        }
    }

    private fun getContactName(context: Context, number: String): String? {
        if (number.isEmpty()) return null
        return try {
            val uri = android.net.Uri.withAppendedPath(
                android.provider.ContactsContract.PhoneLookup.CONTENT_FILTER_URI,
                android.net.Uri.encode(number)
            )
            val cursor = context.contentResolver.query(
                uri,
                arrayOf(android.provider.ContactsContract.PhoneLookup.DISPLAY_NAME),
                null, null, null
            )
            cursor?.use { if (it.moveToFirst()) it.getString(0) else null }
        } catch (e: Exception) { null }
    }
}
