package com.jarvis.ai

import android.app.*
import android.content.*
import android.graphics.Color
import android.graphics.PixelFormat
import android.hardware.camera2.*
import android.media.AudioManager
import android.media.ImageReader
import android.net.Uri
import android.os.*
import android.provider.MediaStore
import android.speech.*
import android.speech.tts.TextToSpeech
import android.telecom.TelecomManager
import android.view.*
import android.view.animation.AlphaAnimation
import android.view.animation.Animation
import android.widget.*
import androidx.core.app.NotificationCompat
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import java.util.concurrent.TimeUnit

class JarvisService : Service(), TextToSpeech.OnInitListener {

    private var speechRecognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var windowManager: WindowManager? = null
    private var overlayView: View? = null
    private var apiKey: String = ""
    private val handler = Handler(Looper.getMainLooper())
    private var isTtsSpeaking = false
    private val conversationHistory = JSONArray()
    private var lastSenderName   = ""
    private var lastSenderNumber = ""
    private var autoAnswerCalls  = true

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    companion object {
        const val CHANNEL_ID        = "jarvis_service"
        const val NOTIF_ID          = 42
        const val ACTION_STOP       = "com.jarvis.ai.STOP"
        const val ACTION_READ_SMS   = "com.jarvis.ai.READ_SMS"
        const val ACTION_INCOMING_CALL = "com.jarvis.ai.INCOMING_CALL"
        const val ACTION_CALL_ENDED = "com.jarvis.ai.CALL_ENDED"
        const val GEMINI_URL        = "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent"

        const val SYSTEM_PROMPT = """You are J.A.R.V.I.S. from Iron Man — a brilliant AI assistant running on Android.
Detect the language (English or Hindi) and ALWAYS reply in the SAME language.
English: polished British wit, address as "Sir". Hindi: friendly, address as "Sir" or "Sahab".
Keep responses SHORT — 2-3 sentences max, you are speaking aloud.

For special device commands, reply ONLY with the matching JSON (nothing else, no explanation):

1. Send SMS:
   {"action":"send_sms","to":"<name>","message":"<text>"}

2. Play YouTube video:
   {"action":"play_youtube","query":"<search terms>"}
   Triggers: "play ... on youtube", "youtube mein ... chalao", "play ... song", "open youtube ... "

3. Take photo / open camera:
   {"action":"take_photo"}
   Triggers: "take a photo", "click picture", "open camera", "photo lo", "selfie lo", "camera kholo"

4. Open an app:
   {"action":"open_app","app":"<app name>"}
   Triggers: "open whatsapp", "open instagram", "open maps", "... app kholo"

5. Answer call:
   {"action":"answer_call"}
   Triggers: "answer", "pick up", "receive call", "call uthao"

6. Reject call:
   {"action":"reject_call"}
   Triggers: "reject", "decline", "cut the call", "call kato"

7. End call:
   {"action":"end_call"}
   Triggers: "end call", "hang up", "call khatam karo"

For everything else respond in plain conversational text.
Never break character. Never mention Google or Gemini."""

        val WAKE_WORDS = listOf(
            "hey jarvis", "jarvis", "ok jarvis", "okay jarvis", "hello jarvis",
            "हे जार्विस", "जार्विस", "ओके जार्विस", "हेलो जार्विस",
            "jar vis", "jarves", "jarwis"
        )
    }

    // ── Lifecycle ──────────────────────────────────────────────────────────

    override fun onCreate() {
        super.onCreate()
        tts = TextToSpeech(this, this)
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> { stopSelf(); return START_NOT_STICKY }

            ACTION_READ_SMS -> {
                val name   = intent.getStringExtra("sender_name")   ?: "Someone"
                val number = intent.getStringExtra("sender_number") ?: ""
                val body   = intent.getStringExtra("sms_body")      ?: ""
                lastSenderName   = name
                lastSenderNumber = number
                readSmsAloud(name, body)
            }

            ACTION_INCOMING_CALL -> {
                val name   = intent.getStringExtra("caller_name")   ?: "Unknown"
                val number = intent.getStringExtra("caller_number") ?: ""
                handleIncomingCall(name, number)
            }

            ACTION_CALL_ENDED -> {
                speak("Call ended, Sir.") { startWakeWordListening() }
            }

            else -> {
                apiKey = intent?.getStringExtra("api_key")
                    ?: getSharedPreferences("jarvis_prefs", Context.MODE_PRIVATE)
                        .getString("api_key", "") ?: ""
                autoAnswerCalls = getSharedPreferences("jarvis_prefs", Context.MODE_PRIVATE)
                    .getBoolean("auto_answer", true)
                startForeground(NOTIF_ID, buildNotification("🎙 Listening for 'Hey Jarvis'…"))
                handler.postDelayed({ startWakeWordListening() }, 1000)
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        removeOverlay(); speechRecognizer?.destroy(); tts?.shutdown()
        handler.removeCallbacksAndMessages(null); super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    // ── TTS ────────────────────────────────────────────────────────────────

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale.US; tts?.setSpeechRate(0.92f); tts?.setPitch(0.80f)
        }
    }

    private fun speak(text: String, onDone: (() -> Unit)? = null) {
        isTtsSpeaking = true
        val utterId = "j_${System.currentTimeMillis()}"
        tts?.setOnUtteranceProgressListener(object : android.speech.tts.UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?)  { isTtsSpeaking = false; onDone?.let { handler.postDelayed(it, 300) } }
            override fun onError(id: String?) { isTtsSpeaking = false; onDone?.let { handler.postDelayed(it, 300) } }
        })
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, Bundle(), utterId)
    }

    // ── SMS ────────────────────────────────────────────────────────────────

    private fun readSmsAloud(senderName: String, body: String) {
        showSmsOverlay(senderName, body)
        speak("Sir, new message from $senderName. They say: $body. Say Hey Jarvis to reply.") {
            startWakeWordListening()
        }
    }

    private fun sendSms(toName: String, message: String) {
        try {
            val number = if (toName == lastSenderName) lastSenderNumber
            else resolveContactNumber(toName) ?: toName
            val smsManager = android.telephony.SmsManager.getDefault()
            smsManager.sendMultipartTextMessage(number, null, smsManager.divideMessage(message), null, null)
            val confirm = "Message sent to $toName, Sir."
            updateOverlayResponse(confirm)
            speak(confirm) { handler.postDelayed({ removeOverlay(); startWakeWordListening() }, 2000) }
        } catch (e: Exception) {
            val err = "Sorry Sir, couldn't send the message."
            updateOverlayResponse(err)
            speak(err) { handler.postDelayed({ removeOverlay(); startWakeWordListening() }, 2000) }
        }
    }

    private fun resolveContactNumber(name: String): String? {
        return try {
            val cursor = contentResolver.query(
                android.provider.ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(android.provider.ContactsContract.CommonDataKinds.Phone.NUMBER,
                    android.provider.ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME),
                "${android.provider.ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
                arrayOf("%$name%"), null
            )
            cursor?.use { if (it.moveToFirst()) it.getString(0) else null }
        } catch (e: Exception) { null }
    }

    // ── CALLS ──────────────────────────────────────────────────────────────

    private fun handleIncomingCall(name: String, number: String) {
        showCallOverlay(name)
        if (autoAnswerCalls) {
            speak("Incoming call from $name, Sir. Answering now.") {
                handler.postDelayed({ answerCall() }, 800)
            }
        } else {
            speak("Incoming call from $name, Sir. Say answer or reject.") {
                startCommandListening()
            }
        }
    }

    private fun answerCall() {
        try {
            val tm = getSystemService(TELECOM_SERVICE) as TelecomManager
            tm.acceptRingingCall()
            handler.postDelayed({
                val audio = getSystemService(AUDIO_SERVICE) as AudioManager
                audio.isSpeakerphoneOn = true
                audio.mode = AudioManager.MODE_IN_CALL
            }, 1000)
            speak("Call connected, Sir.") { removeOverlay() }
        } catch (e: Exception) {
            // Fallback — simulate headset button press
            try {
                val audio = getSystemService(AUDIO_SERVICE) as AudioManager
                val eventDown = Intent(Intent.ACTION_MEDIA_BUTTON).apply {
                    putExtra(Intent.EXTRA_KEY_EVENT, android.view.KeyEvent(android.view.KeyEvent.ACTION_DOWN, android.view.KeyEvent.KEYCODE_HEADSETHOOK))
                }
                val eventUp = Intent(Intent.ACTION_MEDIA_BUTTON).apply {
                    putExtra(Intent.EXTRA_KEY_EVENT, android.view.KeyEvent(android.view.KeyEvent.ACTION_UP, android.view.KeyEvent.KEYCODE_HEADSETHOOK))
                }
                sendOrderedBroadcast(eventDown, null)
                sendOrderedBroadcast(eventUp, null)
                handler.postDelayed({
                    audio.isSpeakerphoneOn = true
                    audio.mode = AudioManager.MODE_IN_CALL
                }, 1000)
                speak("Call connected, Sir.") { removeOverlay() }
            } catch (ex: Exception) {
                speak("Please answer the call manually, Sir.") { removeOverlay() }
            }
        }
    }

    private fun rejectCall() {
        try {
            val tm = getSystemService(TELECOM_SERVICE) as TelecomManager
            tm.endCall()
            speak("Call rejected, Sir.") { removeOverlay(); startWakeWordListening() }
        } catch (e: Exception) {
            speak("Please reject the call manually, Sir.") { removeOverlay() }
        }
    }

    private fun endCall() {
        try {
            val tm = getSystemService(TELECOM_SERVICE) as TelecomManager
            tm.endCall()
            speak("Call ended, Sir.") { removeOverlay(); startWakeWordListening() }
        } catch (e: Exception) {
            speak("Could not end the call, Sir.") { removeOverlay() }
        }
    }

    // ── YOUTUBE ────────────────────────────────────────────────────────────

    private fun playYouTube(query: String) {
        try {
            val encodedQuery = Uri.encode(query)
            // Try YouTube app first, fall back to browser
            val ytAppIntent = Intent(Intent.ACTION_SEARCH).apply {
                setPackage("com.google.android.youtube")
                putExtra("query", query)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            val ytWebIntent = Intent(Intent.ACTION_VIEW,
                Uri.parse("https://www.youtube.com/results?search_query=$encodedQuery")).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }

            try {
                startActivity(ytAppIntent)
            } catch (e: Exception) {
                startActivity(ytWebIntent)
            }

            val response = "Playing $query on YouTube, Sir."
            updateOverlayResponse(response)
            speak(response) { handler.postDelayed({ removeOverlay(); startWakeWordListening() }, 3000) }
        } catch (e: Exception) {
            speak("Sorry Sir, couldn't open YouTube.") {
                handler.postDelayed({ removeOverlay(); startWakeWordListening() }, 2000)
            }
        }
    }

    // ── CAMERA ─────────────────────────────────────────────────────────────

    private fun openCamera() {
        try {
            val cameraIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            startActivity(cameraIntent)
            val response = "Opening camera, Sir. Smile!"
            updateOverlayResponse(response)
            speak(response) { handler.postDelayed({ removeOverlay(); startWakeWordListening() }, 3000) }
        } catch (e: Exception) {
            // Fallback: open camera app directly
            try {
                val fallback = packageManager.getLaunchIntentForPackage("com.android.camera2")
                    ?: packageManager.getLaunchIntentForPackage("com.sec.android.app.camera")
                    ?: packageManager.getLaunchIntentForPackage("com.google.android.GoogleCamera")
                fallback?.apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK }
                    ?.let { startActivity(it) }
                speak("Camera opened, Sir.") {
                    handler.postDelayed({ removeOverlay(); startWakeWordListening() }, 3000)
                }
            } catch (ex: Exception) {
                speak("Sorry Sir, couldn't open the camera.") {
                    handler.postDelayed({ removeOverlay(); startWakeWordListening() }, 2000)
                }
            }
        }
    }

    // ── OPEN APP ───────────────────────────────────────────────────────────

    private fun openApp(appName: String) {
        val appMap = mapOf(
            "whatsapp"   to "com.whatsapp",
            "instagram"  to "com.instagram.android",
            "youtube"    to "com.google.android.youtube",
            "maps"       to "com.google.android.apps.maps",
            "gmail"      to "com.google.android.gm",
            "chrome"     to "com.android.chrome",
            "settings"   to "com.android.settings",
            "camera"     to "com.android.camera2",
            "spotify"    to "com.spotify.music",
            "facebook"   to "com.facebook.katana",
            "twitter"    to "com.twitter.android",
            "telegram"   to "org.telegram.messenger",
            "snapchat"   to "com.snapchat.android",
            "netflix"    to "com.netflix.mediaclient",
            "calculator" to "com.android.calculator2",
            "calendar"   to "com.google.android.calendar",
            "clock"      to "com.android.deskclock",
            "files"      to "com.google.android.documentsui",
            "photos"     to "com.google.android.apps.photos",
            "play store" to "com.android.vending"
        )

        val lowerName = appName.lowercase()
        val packageName = appMap.entries.firstOrNull { lowerName.contains(it.key) }?.value

        try {
            val launchIntent = if (packageName != null) {
                this.packageManager.getLaunchIntentForPackage(packageName)
            } else {
                // Search all installed apps
                this.packageManager.getInstalledApplications(0)
                    .firstOrNull { app ->
                        this.packageManager.getApplicationLabel(app).toString()
                            .lowercase().contains(lowerName)
                    }?.packageName?.let {
                        this.packageManager.getLaunchIntentForPackage(it)
                    }
            }

            if (launchIntent != null) {
                launchIntent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                startActivity(launchIntent)
                val response = "Opening $appName, Sir."
                updateOverlayResponse(response)
                speak(response) { handler.postDelayed({ removeOverlay(); startWakeWordListening() }, 2000) }
            } else {
                speak("I couldn't find $appName on your device, Sir.") {
                    handler.postDelayed({ removeOverlay(); startWakeWordListening() }, 2000)
                }
            }
        } catch (e: Exception) {
            speak("Sorry Sir, couldn't open $appName.") {
                handler.postDelayed({ removeOverlay(); startWakeWordListening() }, 2000)
            }
        }
    }

    // ── Wake word ──────────────────────────────────────────────────────────

    private fun startWakeWordListening() {
        if (isTtsSpeaking) { handler.postDelayed({ startWakeWordListening() }, 600); return }
        updateNotification("🎙 Listening for 'Hey Jarvis'…")
        speechRecognizer?.destroy()
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        speechRecognizer?.setRecognitionListener(wakeWordListener)
        try { speechRecognizer?.startListening(buildIntent(false)) }
        catch (e: Exception) { handler.postDelayed({ startWakeWordListening() }, 1000) }
    }

    private val wakeWordListener = object : RecognitionListener {
        override fun onResults(results: Bundle?) {
            val heard = (results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?: emptyList<String>()).joinToString(" ").lowercase()
            if (WAKE_WORDS.any { heard.contains(it) }) {
                updateNotification("⚡ Command mode…")
                speak("Yes Sir?") { startCommandListening() }
            } else { handler.postDelayed({ startWakeWordListening() }, 200) }
        }
        override fun onError(error: Int) {
            val d = when(error) {
                SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> 100L
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> 800L
                else -> 400L
            }
            handler.postDelayed({ startWakeWordListening() }, d)
        }
        override fun onReadyForSpeech(p: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(v: Float) {}
        override fun onBufferReceived(b: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onPartialResults(p: Bundle?) {}
        override fun onEvent(t: Int, p: Bundle?) {}
    }

    // ── Command listening ──────────────────────────────────────────────────

    private fun startCommandListening() {
        speechRecognizer?.destroy()
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        speechRecognizer?.setRecognitionListener(commandListener)
        try { speechRecognizer?.startListening(buildIntent(true)) }
        catch (e: Exception) {
            speak("Sorry Sir, microphone error.")
            handler.postDelayed({ startWakeWordListening() }, 2000)
        }
    }

    private val commandListener = object : RecognitionListener {
        override fun onResults(results: Bundle?) {
            val command = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull() ?: ""
            if (command.isBlank()) {
                speak("I didn't catch that, Sir.")
                handler.postDelayed({ startWakeWordListening() }, 2000)
                return
            }
            showThinkingOverlay(command)
            callGeminiApi(command)
        }
        override fun onError(error: Int) {
            speak("I didn't catch that, Sir.")
            handler.postDelayed({ startWakeWordListening() }, 2000)
        }
        override fun onReadyForSpeech(p: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(v: Float) {}
        override fun onBufferReceived(b: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onPartialResults(p: Bundle?) {}
        override fun onEvent(t: Int, p: Bundle?) {}
    }

    // ── Gemini API ─────────────────────────────────────────────────────────

    private fun callGeminiApi(command: String) {
        conversationHistory.put(JSONObject().apply {
            put("role", "user")
            put("parts", JSONArray().put(JSONObject().put("text", command)))
        })

        Thread {
            try {
                val body = JSONObject().apply {
                    put("system_instruction", JSONObject().apply {
                        put("parts", JSONArray().put(JSONObject().put("text", SYSTEM_PROMPT)))
                    })
                    put("contents", conversationHistory)
                    put("generationConfig", JSONObject().apply {
                        put("maxOutputTokens", 200); put("temperature", 0.7)
                    })
                }.toString()

                val request = Request.Builder()
                    .url("$GEMINI_URL?key=$apiKey")
                    .post(body.toRequestBody("application/json".toMediaType()))
                    .build()

                val responseBody = httpClient.newCall(request).execute().body?.string() ?: ""
                val reply = JSONObject(responseBody)
                    .getJSONArray("candidates").getJSONObject(0)
                    .getJSONObject("content").getJSONArray("parts")
                    .getJSONObject(0).getString("text").trim()

                conversationHistory.put(JSONObject().apply {
                    put("role", "model")
                    put("parts", JSONArray().put(JSONObject().put("text", reply)))
                })

                handler.post { handleGeminiReply(reply) }

            } catch (e: Exception) {
                val err = "My apologies Sir, trouble reaching servers."
                handler.post {
                    updateOverlayResponse(err)
                    speak(err) { handler.postDelayed({ removeOverlay(); startWakeWordListening() }, 2000) }
                }
            }
        }.start()
    }

    private fun handleGeminiReply(reply: String) {
        // Check for JSON action
        if (reply.trimStart().startsWith("{")) {
            try {
                val json = JSONObject(reply.trim())
                when (json.getString("action")) {
                    "send_sms"     -> sendSms(json.getString("to"), json.getString("message"))
                    "play_youtube" -> { updateOverlayResponse("🎥 Searching YouTube…"); playYouTube(json.getString("query")) }
                    "take_photo"   -> { updateOverlayResponse("📸 Opening camera…"); openCamera() }
                    "open_app"     -> { updateOverlayResponse("📱 Opening ${json.getString("app")}…"); openApp(json.getString("app")) }
                    "answer_call"  -> answerCall()
                    "reject_call"  -> rejectCall()
                    "end_call"     -> endCall()
                    else           -> speakAndReturn(reply)
                }
                return
            } catch (e: Exception) { /* fall through to plain text */ }
        }
        speakAndReturn(reply)
    }

    private fun speakAndReturn(reply: String) {
        updateOverlayResponse(reply)
        speak(reply) { handler.postDelayed({ removeOverlay(); startWakeWordListening() }, 2000) }
    }

    // ── Overlays ───────────────────────────────────────────────────────────

    private fun showThinkingOverlay(command: String) {
        handler.post {
            removeOverlay()
            overlayView = LayoutInflater.from(this).inflate(R.layout.overlay_popup, null)
            overlayView?.apply {
                findViewById<TextView>(R.id.tvCommand).text  = "\"$command\""
                findViewById<TextView>(R.id.tvResponse).text = "Computing…"
                findViewById<TextView>(R.id.tvStatus).text   = "⚡ PROCESSING"
                findViewById<TextView>(R.id.tvStatus).setTextColor(0xFFFFAA00.toInt())
                val blink = AlphaAnimation(0.2f, 1f).apply {
                    duration = 600; repeatMode = Animation.REVERSE; repeatCount = Animation.INFINITE
                }
                findViewById<TextView>(R.id.tvResponse).startAnimation(blink)
                findViewById<View>(R.id.btnClose).setOnClickListener {
                    removeOverlay(); handler.postDelayed({ startWakeWordListening() }, 400)
                }
            }
            addOverlayToWindow()
        }
    }

    private fun showSmsOverlay(senderName: String, body: String) {
        handler.post {
            removeOverlay()
            overlayView = LayoutInflater.from(this).inflate(R.layout.overlay_popup, null)
            overlayView?.apply {
                findViewById<TextView>(R.id.tvCommand).text  = "📩 Message from $senderName"
                findViewById<TextView>(R.id.tvResponse).text = body
                findViewById<TextView>(R.id.tvStatus).text   = "📨 NEW SMS"
                findViewById<TextView>(R.id.tvStatus).setTextColor(0xFF00F5FF.toInt())
                findViewById<View>(R.id.btnClose).setOnClickListener {
                    removeOverlay(); handler.postDelayed({ startWakeWordListening() }, 400)
                }
            }
            addOverlayToWindow()
        }
    }

    private fun showCallOverlay(callerName: String) {
        handler.post {
            removeOverlay()
            overlayView = LayoutInflater.from(this).inflate(R.layout.overlay_popup, null)
            overlayView?.apply {
                findViewById<TextView>(R.id.tvCommand).text  = "📞 Incoming Call"
                findViewById<TextView>(R.id.tvResponse).text = callerName
                findViewById<TextView>(R.id.tvStatus).text   = "📲 CALLING"
                findViewById<TextView>(R.id.tvStatus).setTextColor(0xFF00FF88.toInt())
                val pulse = AlphaAnimation(0.4f, 1f).apply {
                    duration = 700; repeatMode = Animation.REVERSE; repeatCount = Animation.INFINITE
                }
                findViewById<TextView>(R.id.tvResponse).startAnimation(pulse)
                findViewById<View>(R.id.btnClose).setOnClickListener { rejectCall() }
            }
            addOverlayToWindow()
        }
    }

    private fun addOverlayToWindow() {
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.BOTTOM; y = 80 }
        try { windowManager?.addView(overlayView, params) } catch (e: Exception) { e.printStackTrace() }
    }

    private fun updateOverlayResponse(response: String) {
        overlayView?.apply {
            findViewById<TextView>(R.id.tvResponse).clearAnimation()
            findViewById<TextView>(R.id.tvResponse).text = response
            findViewById<TextView>(R.id.tvStatus).text   = "● ONLINE"
            findViewById<TextView>(R.id.tvStatus).setTextColor(0xFF00FF88.toInt())
        }
    }

    private fun removeOverlay() {
        try {
            overlayView?.clearAnimation()
            if (overlayView?.isAttachedToWindow == true) windowManager?.removeView(overlayView)
        } catch (e: Exception) { }
        overlayView = null
    }

    // ── Notification ───────────────────────────────────────────────────────

    private fun createNotificationChannel() {
        val ch = NotificationChannel(CHANNEL_ID, "J.A.R.V.I.S. Service", NotificationManager.IMPORTANCE_LOW).apply {
            description = "Jarvis background listener"; lightColor = Color.CYAN; setShowBadge(false)
        }
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)
    }

    private fun buildNotification(text: String): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(this, 1,
            Intent(this, JarvisService::class.java).apply { action = ACTION_STOP }, PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("J.A.R.V.I.S.").setContentText(text)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setColor(Color.CYAN).setOngoing(true).setContentIntent(open)
            .addAction(android.R.drawable.ic_delete, "Stop", stop)
            .setPriority(NotificationCompat.PRIORITY_LOW).build()
    }

    private fun updateNotification(text: String) {
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(NOTIF_ID, buildNotification(text))
    }

    private fun buildIntent(command: Boolean) = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN")
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN")
        putExtra(RecognizerIntent.EXTRA_ONLY_RETURN_LANGUAGE_PREFERENCE, false)
        putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, if (command) 1 else 5)
        if (command) {
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1800L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1500L)
        }
    }
}
