package com.jarvis.ai

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private val PERM_REQUEST = 100
    private val REQUIRED_PERMISSIONS = arrayOf(
        Manifest.permission.RECORD_AUDIO,
        Manifest.permission.RECEIVE_SMS,
        Manifest.permission.READ_SMS,
        Manifest.permission.SEND_SMS,
        Manifest.permission.READ_CONTACTS,
        Manifest.permission.READ_PHONE_STATE,
        Manifest.permission.ANSWER_PHONE_CALLS,
        Manifest.permission.CAMERA
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        setupUI()
        requestAllPermissions()
    }

    private fun setupUI() {
        val prefs        = getSharedPreferences("jarvis_prefs", MODE_PRIVATE)
        val apiKeyInput  = findViewById<EditText>(R.id.apiKeyInput)
        val startBtn     = findViewById<Button>(R.id.startBtn)
        val stopBtn      = findViewById<Button>(R.id.stopBtn)
        val statusText   = findViewById<TextView>(R.id.statusText)
        val overlayBtn   = findViewById<Button>(R.id.overlayPermBtn)

        apiKeyInput.setText(prefs.getString("api_key", ""))
        updateOverlayButton(overlayBtn)

        overlayBtn.setOnClickListener {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }

        startBtn.setOnClickListener {
            val apiKey = apiKeyInput.text.toString().trim()
            if (apiKey.isEmpty()) { Toast.makeText(this, "Enter your Google AI API key first", Toast.LENGTH_LONG).show(); return@setOnClickListener }
            if (!Settings.canDrawOverlays(this)) { Toast.makeText(this, "Grant Overlay permission first", Toast.LENGTH_LONG).show(); return@setOnClickListener }

            prefs.edit().putString("api_key", apiKey).apply()
            val serviceIntent = Intent(this, JarvisService::class.java).apply { putExtra("api_key", apiKey) }
            startForegroundService(serviceIntent)
            statusText.text = "● JARVIS IS ACTIVE"
            statusText.setTextColor(0xFF00FF88.toInt())
            Toast.makeText(this, "J.A.R.V.I.S. activated!", Toast.LENGTH_LONG).show()
        }

        stopBtn.setOnClickListener {
            stopService(Intent(this, JarvisService::class.java))
            statusText.text = "● OFFLINE"
            statusText.setTextColor(0xFFFF4444.toInt())
        }
    }

    private fun requestAllPermissions() {
        val missing = REQUIRED_PERMISSIONS.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) ActivityCompat.requestPermissions(this, missing.toTypedArray(), PERM_REQUEST)
    }

    private fun updateOverlayButton(btn: Button) {
        if (Settings.canDrawOverlays(this)) { btn.text = "✓ Overlay Permission Granted"; btn.isEnabled = false }
        else { btn.text = "Grant Overlay Permission (Required)"; btn.isEnabled = true }
    }

    override fun onResume() {
        super.onResume()
        updateOverlayButton(findViewById(R.id.overlayPermBtn))
    }
}
