package com.jarvis.ai

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony

class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Telephony.Sms.Intents.SMS_RECEIVED_ACTION) {
            val messages = Telephony.Sms.Intents.getMessagesFromIntent(intent)
            if (messages.isNullOrEmpty()) return

            val sender  = messages[0].displayOriginatingAddress ?: "Unknown"
            val body    = messages.joinToString("") { it.messageBody ?: "" }

            // Resolve contact name from number
            val name = getContactName(context, sender) ?: sender

            // Tell JarvisService to read the SMS aloud
            val serviceIntent = Intent(context, JarvisService::class.java).apply {
                action = JarvisService.ACTION_READ_SMS
                putExtra("sender_name",   name)
                putExtra("sender_number", sender)
                putExtra("sms_body",      body)
            }
            context.startForegroundService(serviceIntent)
        }
    }

    private fun getContactName(context: Context, number: String): String? {
        return try {
            val uri = android.net.Uri.withAppendedPath(
                android.provider.ContactsContract.PhoneLookup.CONTENT_FILTER_URI,
                android.net.Uri.encode(number)
            )
            val cursor = context.contentResolver.query(
                uri,
                arrayOf(android.provider.ContactsContract.PhoneLookup.DISPLAY_NAME),
                null, null, null
            )
            cursor?.use {
                if (it.moveToFirst()) it.getString(0) else null
            }
        } catch (e: Exception) { null }
    }
}
